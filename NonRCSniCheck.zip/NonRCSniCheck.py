import subprocess
import socket
import ssl
import sys

def main_menu():
    while True:
        print("\n==============================")
        print("  TS HACKER BUG HOST FINDER")
        print("==============================")
        print("[1] Single Domain Test")
        print("[2] Bulk Domain Test (comma-separated)")
        print("[0] Exit")
        choice = input("Select option: ")

        if choice == '1':
            domain_input(single=True)
        elif choice == '2':
            domain_input(single=False)
        elif choice == '0':
            sys.exit("Exiting tool. Bye!")
        else:
            print("Invalid choice. Try again.")

def domain_input(single):
    if single:
        domain = input("Enter domain: ").strip()
        domains = [domain]
    else:
        domain_line = input("Enter domains (comma-separated): ")
        domains = [d.strip() for d in domain_line.split(",") if d.strip()]

    for d in domains:
        run_full_test(d)

def run_full_test(domain):
    print(f"\n=== Running tests on {domain} ===")
    traceroute_result = traceroute_test(domain)
    tcp_result = zero_data_tcp_test(domain)
    ssl_result = ssl_handshake_test(domain)

    print("\n--- Summary ---")
    print(f"Traceroute: {'PASS' if traceroute_result else 'FAIL'}")
    print(f"Zero Data TCP Connect (443): {'PASS' if tcp_result else 'FAIL'}")
    print(f"SSL Handshake: {'PASS' if ssl_result else 'FAIL'}")

    if traceroute_result and tcp_result and ssl_result:
        print(f"\n✅ {domain} is a WORKING bug host!")
    else:
        print(f"\n❌ {domain} is NOT a working bug host.")

def traceroute_test(domain):
    print(f"\n--- Traceroute to {domain} ---")
    try:
        output = subprocess.check_output(['traceroute', domain], stderr=subprocess.STDOUT, universal_newlines=True)
        print(output)
        # Check for public IP pattern in traceroute output
        if any('10.' not in line and '100.' not in line and domain not in line for line in output.splitlines()):
            return True
        else:
            return False
    except Exception as e:
        print(f"Traceroute failed: {e}")
        return False

def zero_data_tcp_test(domain):
    print(f"\n--- Zero Data TCP Test on {domain}:443 ---")
    try:
        sock = socket.create_connection((domain, 443), timeout=5)
        print("TCP connect success (zero-rated!)")
        sock.close()
        return True
    except Exception as e:
        print(f"TCP connect failed: {e}")
        return False

def ssl_handshake_test(domain):
    print(f"\n--- SSL Handshake on {domain}:443 ---")
    try:
        context = ssl.create_default_context()
        with socket.create_connection((domain, 443), timeout=5) as sock:
            with context.wrap_socket(sock, server_hostname=domain) as ssock:
                cert = ssock.getpeercert()
                print(f"SSL subject: {cert['subject']}")
        return True
    except Exception as e:
        print(f"SSL handshake failed: {e}")
        return False

if __name__ == "__main__":
    main_menu()
