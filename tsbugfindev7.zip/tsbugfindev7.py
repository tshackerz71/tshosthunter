# TSHACKER - SNI Bug Finder V7.0 (Termux + PC)
# 100% Accurate | Separate Feature Scan | Zero Balance Real Check | Multi-port | Payload | Clean CLI

import socket, ssl, requests, subprocess, time, os
from concurrent.futures import ThreadPoolExecutor

multi_ports = [443, 80, 8080, 8443]
headers_template = {
    "User-Agent": "Mozilla/5.0 (Linux; Android 10) Chrome/90.0.4430.91 Mobile Safari/537.36",
    "Host": "{domain}",
    "X-Online-Host": "{domain}"
}

def dns_check(domain):
    try:
        ip = socket.gethostbyname(domain)
        print(f"✅ DNS Resolved: {domain} -> {ip}")
    except:
        print("❌ DNS resolution failed.")

def tls_handshake(domain):
    try:
        ip = socket.gethostbyname(domain)
        cmd = ["curl", "-m", "5", "-s", "-v", "--resolve", f"{domain}:443:{ip}", f"https://{domain}"]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if "SSL connection using" in result.stderr:
            print("✅ TLS Handshake Success")
        else:
            print("❌ TLS Handshake Failed")
    except:
        print("❌ TLS check error.")

def http_status(domain):
    try:
        h = {k: v.format(domain=domain) for k,v in headers_template.items()}
        r = requests.get(f"https://{domain}", headers=h, timeout=6, allow_redirects=True)
        print(f"✅ HTTP Status: {r.status_code}")
        if r.is_redirect or r.history:
            for resp in r.history:
                print(f"🔁 Redirect: {resp.status_code} -> {resp.headers.get('Location')}")
    except:
        print("❌ HTTP status failed.")

def zero_balance_test(domain):
    try:
        cmd = ["curl", "-m", "6", "-s", "-I", f"https://{domain}"]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.stdout:
            print("✅ Zero-balance data flow possible (headers received)")
        else:
            print("❌ No data flow detected on zero balance")
    except:
        print("❌ Zero-balance test error.")

def sni_fingerprint(domain):
    try:
        context = ssl.create_default_context()
        conn = context.wrap_socket(socket.socket(), server_hostname=domain)
        conn.settimeout(5)
        start = time.time()
        conn.connect((domain, 443))
        latency = round((time.time() - start) * 1000)
        cert = conn.getpeercert()
        print(f"✅ TLS {conn.version()} in {latency}ms | Cipher: {conn.cipher()[0]}")
        print(f"Issuer: {cert.get('issuer')}")
        conn.close()
    except Exception as e:
        print(f"❌ SNI Fingerprint Failed: {e}")

def multi_port_test(domain):
    for port in multi_ports:
        try:
            context = ssl.create_default_context()
            conn = context.wrap_socket(socket.socket(), server_hostname=domain)
            conn.settimeout(5)
            conn.connect((domain, port))
            print(f"✅ Port {port} TLS OK")
            conn.close()
        except:
            print(f"❌ Port {port} failed")

def payload_generator(domain):
    payload = f"GET wss://{domain}/ HTTP/1.1\r\nHost: {domain}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n\r\n"
    print(f"Generated Payload:\n{payload}")

def isp_info():
    try:
        r = requests.get("http://ip-api.com/json", timeout=5)
        d = r.json()
        print(f"🌐 ISP: {d.get('isp')} | Org: {d.get('org')} | IP: {d.get('query')}")
    except:
        print("❌ ISP detection failed.")

def bulk_scan(domains, func):
    with ThreadPoolExecutor(max_workers=5) as ex:
        ex.map(func, domains)

def main():
    while True:
        print("\n🔥 TSHACKER SNI Bug Finder V7.0")
        print("1️⃣ DNS Check")
        print("2️⃣ TLS Handshake Check")
        print("3️⃣ HTTP Status + Redirect")
        print("4️⃣ Zero Balance Data Test")
        print("5️⃣ SNI Fingerprint")
        print("6️⃣ Multi-port SNI Bug Test")
        print("7️⃣ Generate Payload")
        print("8️⃣ ISP / Network Info")
        print("9️⃣ Bulk Scan (choose feature)")
        print("🔟 Exit")
        c = input("Select option: ").strip()
        if c == "1": dns_check(input("Domain: ").strip())
        elif c == "2": tls_handshake(input("Domain: ").strip())
        elif c == "3": http_status(input("Domain: ").strip())
        elif c == "4": zero_balance_test(input("Domain: ").strip())
        elif c == "5": sni_fingerprint(input("Domain: ").strip())
        elif c == "6": multi_port_test(input("Domain: ").strip())
        elif c == "7": payload_generator(input("Domain: ").strip())
        elif c == "8": isp_info()
        elif c == "9":
            print("Which feature for bulk?")
            print("1-DNS 2-TLS 3-HTTP 4-ZeroBal 5-Fingerprint 6-MultiPort")
            f = input("Choice: ").strip()
            print("Paste domains, empty line to end:")
            ds = []
            while True:
                d = input().strip()
                if not d: break
                ds.append(d)
            funcs = {"1": dns_check, "2": tls_handshake, "3": http_status,
                     "4": zero_balance_test, "5": sni_fingerprint, "6": multi_port_test}
            if f in funcs:
                bulk_scan(ds, funcs[f])
            else:
                print("❌ Invalid bulk feature.")
        elif c == "10":
            print("Jai Hind 🇮🇳")
            break
        else:
            print("❌ Invalid choice.")

if __name__ == "__main__":
    main()
