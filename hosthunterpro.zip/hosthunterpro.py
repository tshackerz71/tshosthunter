import subprocess
import socket
import ssl
import whois
import sys

def main_menu():
    license_key = input("Enter license key to use TS HACKER HOST HUNTER TOOL: ").strip()
    if license_key != "tspapa71":
        sys.exit("Invalid license key. Exiting.")

    while True:
        print("\n==============================")
        print("  TS HACKER HOST HUNTER TOOL")
        print("==============================")
        print("[1] Single Domain Test")
        print("[2] Bulk Domain Test (comma-separated)")
        print("[0] Exit")
        choice = input("Select option: ")

        if choice == '1':
            domain_input(single=True)
        elif choice == '2':
            domain_input(single=False)
        elif choice == '0':
            sys.exit("Exiting TS HACKER HOST HUNTER TOOL. Bye!")
        else:
            print("Invalid choice. Try again.")

def domain_input(single):
    if single:
        domain = input("Enter domain: ").strip()
        domains = [domain]
    else:
        domain_line = input("Enter domains (comma-separated): ")
        domains = [d.strip() for d in domain_line.split(",") if d.strip()]

    while True:
        print("\nAvailable Checks:")
        print("[1] Ping Test")
        print("[2] DNS Lookup")
        print("[3] Traceroute")
        print("[4] WHOIS Info")
        print("[5] SSL/TLS Check (80 & 443)")
        print("[6] Socket Port Scan")
        print("[7] Nmap Port Scan")
        print("[B] Back")
        print("[0] Exit")
        choice = input("Select test: ").upper()

        if choice == '1':
            for d in domains: ping_test(d)
        elif choice == '2':
            for d in domains: dns_lookup(d)
        elif choice == '3':
            for d in domains: traceroute(d)
        elif choice == '4':
            for d in domains: whois_info(d)
        elif choice == '5':
            for d in domains: ssl_tls_check(d)
        elif choice == '6':
            ports = input("Enter ports to scan (e.g., 80,443,8080): ")
            ports = [int(p.strip()) for p in ports.split(",") if p.strip().isdigit()]
            for d in domains: socket_port_scan(d, ports)
        elif choice == '7':
            ports = input("Enter ports to scan (e.g., 80,443,8080): ")
            port_str = ",".join([p.strip() for p in ports.split(",") if p.strip().isdigit()])
            for d in domains: nmap_port_scan(d, port_str)
        elif choice == 'B':
            return
        elif choice == '0':
            sys.exit("Exiting TS HACKER HOST HUNTER TOOL. Bye!")
        else:
            print("Invalid choice. Try again.")

def ping_test(domain):
    print(f"\n--- Pinging {domain} ---")
    try:
        subprocess.run(['ping', '-c', '2', domain], check=True)
    except subprocess.CalledProcessError:
        print(f"Ping failed or blocked for {domain}")

def dns_lookup(domain):
    print(f"\n--- DNS Lookup {domain} ---")
    try:
        ip = socket.gethostbyname(domain)
        print(f"Resolved IP: {ip}")
    except socket.gaierror:
        print("DNS resolution failed.")

def traceroute(domain):
    print(f"\n--- Traceroute to {domain} ---")
    try:
        subprocess.run(['traceroute', domain], check=True)
    except Exception as e:
        print(f"Traceroute failed: {e}")

def whois_info(domain):
    print(f"\n--- WHOIS info for {domain} ---")
    try:
        w = whois.whois(domain)
        print(w)
    except Exception as e:
        print(f"WHOIS lookup failed: {e}")

def ssl_tls_check(domain):
    for port in [80, 443]:
        print(f"\n--- SSL/TLS Check on {domain}:{port} ---")
        try:
            context = ssl.create_default_context()
            with socket.create_connection((domain, port), timeout=5) as sock:
                with context.wrap_socket(sock, server_hostname=domain) as ssock:
                    cert = ssock.getpeercert()
                    print(f"Cert on {port}: {cert['subject']}")
        except Exception as e:
            print(f"SSL/TLS failed on port {port}: {e}")

def socket_port_scan(domain, ports):
    print(f"\n--- Socket Port Scan on {domain} ---")
    for port in ports:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            result = sock.connect_ex((domain, port))
            if result == 0:
                print(f"Port {port} OPEN")
            else:
                print(f"Port {port} CLOSED")
            sock.close()
        except Exception as e:
            print(f"Error scanning port {port}: {e}")

def nmap_port_scan(domain, port_str):
    print(f"\n--- Nmap Port Scan on {domain} ---")
    try:
        subprocess.run(['nmap', '-p', port_str, domain], check=True)
    except Exception as e:
        print(f"Nmap scan failed: {e}")

if __name__ == "__main__":
    main_menu()
